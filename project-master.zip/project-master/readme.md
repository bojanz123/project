Igra pogadjanja sa brojem linija:
24

